<?php 
	$conn = mysqli_connect($mysql_host, $mysql_name, $mysql_pass, $mysql_db);
        if($conn) {
          echo "CONNECTED!";
        }
        if(isset($_GET['email']) && !empty($_GET['email']) AND isset($_GET['hash']) && !empty($_GET['hash'])){

        	$email = $_GET['email']// Set email variable
    $hash = $_GET['hash']// Set hash variable
    // Verify data
        	$search = mysqli_query($conn, "SELECT email, verification FROM users WHERE email='".$email."' AND verification='".$hash."'"); 
			$match  = mysqli_num_rows($search);
			if($match > 0){
    			// We have a match, activate the account
				mysqli_query($conn, "UPDATE users SET verification='1' WHERE email='".$email."' AND verification='".$hash."'");
			}else{
   				// No match -> invalid url or account has already been activated.
   				print "Invalid token or account is already activated!";
			}
		else{
   		 header("root.brickcraftmc.nl:9985");
		}
 ?>