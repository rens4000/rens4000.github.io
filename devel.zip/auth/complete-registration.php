<?php
	$code = $_GET['code'];
	if($code) {
		echo "Registration successfull. \n";
		echo $code; 
	}
?>