<?php 
$mysql_pass = "BFUfVEQP9gzZ";
$mysql_host = "mysql.hostinger.nl";
$mysql_user = "u617923320_root";
$mysql_db = "u617923320_pdc";
 ?>