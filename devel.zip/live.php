<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
    <link rel="stylesheet" href="./css/style.css">
	</head>
	<body>
    <header>
      <div class="container">
        <div id="branding">
          <h1>Plugin<span id="coding">Development</span>Contest</h1>
        </div>
        <nav>
          <ul>
            <li><a href="index.php">Home</a></li>
						<li class="current"><a href="live.php">Live contest</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <section id="showcase">
      <div class="container">
        <h1>Live development contest</h1>
        <p>Theme: Magic</p>
      </div>
    </section>
    <section id="live">
      <div class="container">
        <center>
          <h1>LIVE CONTEST!</h1>
          <table class="rwd-table">
  <tr>
    <th>Participant</th>
    <th>Github-Repo</th>
    <th>Status</th>
    <th>Points</th>
  </tr>
  <tr>
    <td>rens4000</td>
    <td><a href="https://github.com/rens4000/BountyHunters">https://github.com/rens4000/BountyHunters</a></td>
    <td>Done</td>
    <td>100</td>
  </tr>
</table>

        </center>
      </div>
    </section>
      <footer>
      <p>PluginDevelopmentContest, Copyright &copy; 2017</p>
    </footer>
	</body>
</html>
